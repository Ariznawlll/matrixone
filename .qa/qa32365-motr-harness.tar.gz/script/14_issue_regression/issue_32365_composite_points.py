#!/usr/bin/env python3
# Runs on both main and 4.2-dev; branch-specific output remains available.
"""#32365: composite primary-key OR points retain selective prepared scans."""
import os
import re
import uuid
import pymysql

name = 'qa32365_' + uuid.uuid4().hex[:12]
conn = pymysql.connect(host=os.environ['MO_HOST'], port=int(os.environ['MO_PORT']),
                       user=os.environ['MO_USER'], password=os.environ['MO_PASSWORD'],
                       autocommit=True, connect_timeout=10, read_timeout=120)
created = False
try:
    with conn.cursor() as cur:
        def sql(query):
            cur.execute(query)
            return cur.fetchall() if cur.description else ()

        sql('create database `' + name + '`')
        created = True
        sql('use `' + name + '`')
        sql('create table t (tenant varchar(16) not null, session_id varchar(16) not null, '
            'request_id varchar(16) not null, result varchar(16), '
            'primary key (tenant,session_id,request_id))')
        sql("insert into t select 'user','session',concat('q',lpad(result,6,'0')),null "
            'from generate_series(0,99999) g')
        sql("prepare p from 'explain analyze select result from t where tenant=? and "
            "((session_id=? and request_id=?) or (session_id=? and request_id=?))'")
        sql("set @tenant='user',@s1='session',@k1='q000001',@s2='session',@k2='q000002'")
        for _ in range(3):
            plan = ' '.join(str(row[0]) for row in sql('execute p using @tenant,@s1,@k1,@s2,@k2'))
            match = re.search(r'Table Scan on .*?inputBlocks=\d+ inputRows=(\d+) outputRows=(\d+)', plan, re.S)
            if not match or match.groups() != ('2', '2'):
                raise AssertionError('two-point selective scan missing: ' + repr(match.groups() if match else plan))
        sql('deallocate prepare p')
        sql("prepare p from 'select request_id from t where tenant=? and "
            "((session_id=? and request_id=?) or (session_id=? and request_id=?)) order by request_id'")
        for key1, key2, expected in [('q000001','q000002',(('q000001',),('q000002',))),
                                     ('q000003','q000004',(('q000003',),('q000004',)))]:
            sql("set @k1='%s',@k2='%s'" % (key1,key2))
            actual = sql('execute p using @tenant,@s1,@k1,@s2,@k2')
            if actual != expected:
                raise AssertionError('rebind rows: ' + repr(actual))
        sql('set @k1=null,@k2=null')
        if sql('execute p using @tenant,@s1,@k1,@s2,@k2') != ():
            raise AssertionError('NULL must not match')
        sql('deallocate prepare p')
        keys = ["(session_id='session' and request_id='q%06d')" % i for i in range(50)]
        condition = "tenant='user' and (" + ' or '.join(keys) + ')'
        sql('begin')
        cur.execute("update t set result='marked' where " + condition)
        if cur.rowcount != 50 or sql("select count(*) from t where result='marked'") != ((50,),):
            raise AssertionError('50-point update did not affect exactly 50 rows')
        sql('rollback')
        if sql("select count(*) from t where result='marked'") != ((0,),):
            raise AssertionError('rollback left changed rows')
        print('PASS: composite point prepared scans, rebind, NULL and update rollback')
finally:
    if created:
        with conn.cursor() as cur:
            cur.execute('drop database if exists `' + name + '`')
    conn.close()
